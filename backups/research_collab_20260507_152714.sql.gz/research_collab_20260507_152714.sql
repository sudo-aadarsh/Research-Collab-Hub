--
-- PostgreSQL database dump
--

\restrict N4ddkO3Dl2r9HS4I2VNhqXLU3EtoUO4SvKm5Pa3d1KjrhKpESrTCBd82okZTGUl

-- Dumped from database version 16.12
-- Dumped by pg_dump version 16.12

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: collaboration_role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.collaboration_role AS ENUM (
    'lead',
    'co_author',
    'contributor',
    'reviewer'
);


ALTER TYPE public.collaboration_role OWNER TO postgres;

--
-- Name: paper_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.paper_status AS ENUM (
    'draft',
    'in_review',
    'submitted',
    'accepted',
    'rejected',
    'published'
);


ALTER TYPE public.paper_status OWNER TO postgres;

--
-- Name: project_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.project_status AS ENUM (
    'planning',
    'active',
    'on_hold',
    'completed',
    'cancelled'
);


ALTER TYPE public.project_status OWNER TO postgres;

--
-- Name: recommendation_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.recommendation_type AS ENUM (
    'collaborator',
    'conference',
    'journal',
    'reference'
);


ALTER TYPE public.recommendation_type OWNER TO postgres;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.user_role AS ENUM (
    'researcher',
    'admin',
    'reviewer',
    'guest'
);


ALTER TYPE public.user_role OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ai_collaboration_recommendations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_collaboration_recommendations (
    for_user_id uuid NOT NULL,
    recommended_id uuid NOT NULL,
    score double precision NOT NULL,
    reasons character varying[],
    common_topics character varying[],
    is_dismissed boolean,
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.ai_collaboration_recommendations OWNER TO postgres;

--
-- Name: collaboration_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.collaboration_requests (
    requester_id uuid NOT NULL,
    target_id uuid NOT NULL,
    project_id uuid,
    paper_id uuid,
    message text,
    status character varying(50),
    responded_at character varying,
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.collaboration_requests OWNER TO postgres;

--
-- Name: conferences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.conferences (
    name character varying(500) NOT NULL,
    abbreviation character varying(50),
    description character varying,
    website character varying(500),
    location character varying(255),
    country character varying(100),
    is_virtual boolean,
    research_areas character varying[],
    acceptance_rate double precision,
    impact_factor double precision,
    ranking character varying(50),
    submission_deadline timestamp with time zone,
    notification_date timestamp with time zone,
    conference_date timestamp with time zone,
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.conferences OWNER TO postgres;

--
-- Name: journals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.journals (
    name character varying(500) NOT NULL,
    abbreviation character varying(100),
    issn character varying(20),
    publisher character varying(255),
    website character varying(500),
    impact_factor double precision,
    h_index integer,
    research_areas character varying[],
    open_access boolean,
    acceptance_rate double precision,
    review_speed integer,
    ranking character varying(50),
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.journals OWNER TO postgres;

--
-- Name: paper_authors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.paper_authors (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    paper_id uuid NOT NULL,
    user_id uuid,
    author_name character varying(255) NOT NULL,
    author_email character varying(255),
    order_index integer DEFAULT 0 NOT NULL,
    is_corresponding boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.paper_authors OWNER TO postgres;

--
-- Name: paper_references; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.paper_references (
    paper_id uuid NOT NULL,
    reference_id uuid NOT NULL,
    context text,
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.paper_references OWNER TO postgres;

--
-- Name: paper_submissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.paper_submissions (
    paper_id uuid NOT NULL,
    conference_id uuid,
    journal_id uuid,
    submitted_at timestamp with time zone,
    status character varying(50),
    decision_date timestamp with time zone,
    reviewer_notes character varying,
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.paper_submissions OWNER TO postgres;

--
-- Name: paper_summaries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.paper_summaries (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    paper_id uuid NOT NULL,
    summary text,
    key_points text[],
    generated_at timestamp with time zone DEFAULT now(),
    model_used character varying(100) DEFAULT 'claude-sonnet-4-20250514'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.paper_summaries OWNER TO postgres;

--
-- Name: paper_versions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.paper_versions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    paper_id uuid NOT NULL,
    version integer NOT NULL,
    pdf_url character varying(1000),
    change_log text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.paper_versions OWNER TO postgres;

--
-- Name: papers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.papers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    project_id uuid,
    title character varying(1000) NOT NULL,
    abstract text,
    keywords text[],
    status public.paper_status DEFAULT 'draft'::public.paper_status,
    doi character varying(255),
    arxiv_id character varying(100),
    pdf_url character varying(1000),
    word_count integer,
    page_count integer,
    submission_date date,
    published_date date,
    version integer DEFAULT 1,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.papers OWNER TO postgres;

--
-- Name: project_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project_members (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    project_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role public.collaboration_role DEFAULT 'contributor'::public.collaboration_role,
    joined_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.project_members OWNER TO postgres;

--
-- Name: project_milestones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project_milestones (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    project_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    due_date date,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.project_milestones OWNER TO postgres;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.projects (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    status public.project_status DEFAULT 'planning'::public.project_status,
    owner_id uuid NOT NULL,
    start_date date,
    end_date date,
    funding_info text,
    tags text[],
    is_public boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT valid_dates CHECK (((end_date IS NULL) OR (end_date >= start_date)))
);


ALTER TABLE public.projects OWNER TO postgres;

--
-- Name: references; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."references" (
    paper_id uuid,
    title character varying(1000) NOT NULL,
    authors character varying[],
    year integer,
    doi character varying(255),
    arxiv_id character varying(100),
    journal character varying(500),
    conference character varying(500),
    url character varying(1000),
    citation_key character varying(100),
    abstract text,
    tags character varying[],
    added_by uuid,
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public."references" OWNER TO postgres;

--
-- Name: research_interests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.research_interests (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    topic character varying(255) NOT NULL,
    weight double precision DEFAULT 1.0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.research_interests OWNER TO postgres;

--
-- Name: user_skills; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_skills (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    skill character varying(255) NOT NULL,
    level character varying(50),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT user_skills_level_check CHECK (((level)::text = ANY ((ARRAY['beginner'::character varying, 'intermediate'::character varying, 'expert'::character varying])::text[])))
);


ALTER TABLE public.user_skills OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    username character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    full_name character varying(255) NOT NULL,
    role public.user_role DEFAULT 'researcher'::public.user_role NOT NULL,
    institution character varying(255),
    department character varying(255),
    bio text,
    orcid_id character varying(50),
    h_index integer DEFAULT 0,
    avatar_url character varying(500),
    is_active boolean DEFAULT true,
    is_verified boolean DEFAULT false,
    last_login timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: ai_collaboration_recommendations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_collaboration_recommendations (for_user_id, recommended_id, score, reasons, common_topics, is_dismissed, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: collaboration_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.collaboration_requests (requester_id, target_id, project_id, paper_id, message, status, responded_at, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: conferences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.conferences (name, abbreviation, description, website, location, country, is_virtual, research_areas, acceptance_rate, impact_factor, ranking, submission_deadline, notification_date, conference_date, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: journals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.journals (name, abbreviation, issn, publisher, website, impact_factor, h_index, research_areas, open_access, acceptance_rate, review_speed, ranking, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: paper_authors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.paper_authors (id, paper_id, user_id, author_name, author_email, order_index, is_corresponding, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: paper_references; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.paper_references (paper_id, reference_id, context, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: paper_submissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.paper_submissions (paper_id, conference_id, journal_id, submitted_at, status, decision_date, reviewer_notes, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: paper_summaries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.paper_summaries (id, paper_id, summary, key_points, generated_at, model_used, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: paper_versions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.paper_versions (id, paper_id, version, pdf_url, change_log, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: papers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.papers (id, project_id, title, abstract, keywords, status, doi, arxiv_id, pdf_url, word_count, page_count, submission_date, published_date, version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: project_members; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project_members (id, project_id, user_id, role, joined_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: project_milestones; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project_milestones (id, project_id, title, description, due_date, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.projects (id, title, description, status, owner_id, start_date, end_date, funding_info, tags, is_public, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: references; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."references" (paper_id, title, authors, year, doi, arxiv_id, journal, conference, url, citation_key, abstract, tags, added_by, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: research_interests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.research_interests (id, user_id, topic, weight, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_skills; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_skills (id, user_id, skill, level, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, username, password_hash, full_name, role, institution, department, bio, orcid_id, h_index, avatar_url, is_active, is_verified, last_login, created_at, updated_at) FROM stdin;
\.


--
-- Name: ai_collaboration_recommendations ai_collaboration_recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_collaboration_recommendations
    ADD CONSTRAINT ai_collaboration_recommendations_pkey PRIMARY KEY (id);


--
-- Name: collaboration_requests collaboration_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.collaboration_requests
    ADD CONSTRAINT collaboration_requests_pkey PRIMARY KEY (id);


--
-- Name: conferences conferences_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conferences
    ADD CONSTRAINT conferences_pkey PRIMARY KEY (id);


--
-- Name: journals journals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.journals
    ADD CONSTRAINT journals_pkey PRIMARY KEY (id);


--
-- Name: paper_authors paper_authors_paper_id_order_index_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paper_authors
    ADD CONSTRAINT paper_authors_paper_id_order_index_key UNIQUE (paper_id, order_index);


--
-- Name: paper_authors paper_authors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paper_authors
    ADD CONSTRAINT paper_authors_pkey PRIMARY KEY (id);


--
-- Name: paper_references paper_references_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paper_references
    ADD CONSTRAINT paper_references_pkey PRIMARY KEY (id);


--
-- Name: paper_submissions paper_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paper_submissions
    ADD CONSTRAINT paper_submissions_pkey PRIMARY KEY (id);


--
-- Name: paper_summaries paper_summaries_paper_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paper_summaries
    ADD CONSTRAINT paper_summaries_paper_id_key UNIQUE (paper_id);


--
-- Name: paper_summaries paper_summaries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paper_summaries
    ADD CONSTRAINT paper_summaries_pkey PRIMARY KEY (id);


--
-- Name: paper_versions paper_versions_paper_id_version_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paper_versions
    ADD CONSTRAINT paper_versions_paper_id_version_key UNIQUE (paper_id, version);


--
-- Name: paper_versions paper_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paper_versions
    ADD CONSTRAINT paper_versions_pkey PRIMARY KEY (id);


--
-- Name: papers papers_doi_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.papers
    ADD CONSTRAINT papers_doi_key UNIQUE (doi);


--
-- Name: papers papers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.papers
    ADD CONSTRAINT papers_pkey PRIMARY KEY (id);


--
-- Name: project_members project_members_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_members
    ADD CONSTRAINT project_members_pkey PRIMARY KEY (id);


--
-- Name: project_members project_members_project_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_members
    ADD CONSTRAINT project_members_project_id_user_id_key UNIQUE (project_id, user_id);


--
-- Name: project_milestones project_milestones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_milestones
    ADD CONSTRAINT project_milestones_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: references references_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."references"
    ADD CONSTRAINT references_pkey PRIMARY KEY (id);


--
-- Name: research_interests research_interests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.research_interests
    ADD CONSTRAINT research_interests_pkey PRIMARY KEY (id);


--
-- Name: research_interests research_interests_user_id_topic_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.research_interests
    ADD CONSTRAINT research_interests_user_id_topic_key UNIQUE (user_id, topic);


--
-- Name: user_skills user_skills_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_skills
    ADD CONSTRAINT user_skills_pkey PRIMARY KEY (id);


--
-- Name: user_skills user_skills_user_id_skill_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_skills
    ADD CONSTRAINT user_skills_user_id_skill_key UNIQUE (user_id, skill);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: ix_ai_collaboration_recommendations_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_ai_collaboration_recommendations_id ON public.ai_collaboration_recommendations USING btree (id);


--
-- Name: ix_collaboration_requests_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_collaboration_requests_id ON public.collaboration_requests USING btree (id);


--
-- Name: ix_conferences_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_conferences_id ON public.conferences USING btree (id);


--
-- Name: ix_journals_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_journals_id ON public.journals USING btree (id);


--
-- Name: ix_paper_references_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_paper_references_id ON public.paper_references USING btree (id);


--
-- Name: ix_paper_submissions_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_paper_submissions_id ON public.paper_submissions USING btree (id);


--
-- Name: ix_references_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_references_id ON public."references" USING btree (id);


--
-- Name: ai_collaboration_recommendations ai_collaboration_recommendations_for_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_collaboration_recommendations
    ADD CONSTRAINT ai_collaboration_recommendations_for_user_id_fkey FOREIGN KEY (for_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_collaboration_recommendations ai_collaboration_recommendations_recommended_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_collaboration_recommendations
    ADD CONSTRAINT ai_collaboration_recommendations_recommended_id_fkey FOREIGN KEY (recommended_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: collaboration_requests collaboration_requests_paper_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.collaboration_requests
    ADD CONSTRAINT collaboration_requests_paper_id_fkey FOREIGN KEY (paper_id) REFERENCES public.papers(id);


--
-- Name: collaboration_requests collaboration_requests_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.collaboration_requests
    ADD CONSTRAINT collaboration_requests_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: collaboration_requests collaboration_requests_requester_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.collaboration_requests
    ADD CONSTRAINT collaboration_requests_requester_id_fkey FOREIGN KEY (requester_id) REFERENCES public.users(id);


--
-- Name: collaboration_requests collaboration_requests_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.collaboration_requests
    ADD CONSTRAINT collaboration_requests_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.users(id);


--
-- Name: paper_authors paper_authors_paper_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paper_authors
    ADD CONSTRAINT paper_authors_paper_id_fkey FOREIGN KEY (paper_id) REFERENCES public.papers(id) ON DELETE CASCADE;


--
-- Name: paper_authors paper_authors_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paper_authors
    ADD CONSTRAINT paper_authors_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: paper_references paper_references_paper_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paper_references
    ADD CONSTRAINT paper_references_paper_id_fkey FOREIGN KEY (paper_id) REFERENCES public.papers(id) ON DELETE CASCADE;


--
-- Name: paper_references paper_references_reference_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paper_references
    ADD CONSTRAINT paper_references_reference_id_fkey FOREIGN KEY (reference_id) REFERENCES public."references"(id) ON DELETE CASCADE;


--
-- Name: paper_submissions paper_submissions_conference_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paper_submissions
    ADD CONSTRAINT paper_submissions_conference_id_fkey FOREIGN KEY (conference_id) REFERENCES public.conferences(id);


--
-- Name: paper_submissions paper_submissions_journal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paper_submissions
    ADD CONSTRAINT paper_submissions_journal_id_fkey FOREIGN KEY (journal_id) REFERENCES public.journals(id);


--
-- Name: paper_submissions paper_submissions_paper_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paper_submissions
    ADD CONSTRAINT paper_submissions_paper_id_fkey FOREIGN KEY (paper_id) REFERENCES public.papers(id) ON DELETE CASCADE;


--
-- Name: paper_summaries paper_summaries_paper_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paper_summaries
    ADD CONSTRAINT paper_summaries_paper_id_fkey FOREIGN KEY (paper_id) REFERENCES public.papers(id) ON DELETE CASCADE;


--
-- Name: paper_versions paper_versions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paper_versions
    ADD CONSTRAINT paper_versions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: paper_versions paper_versions_paper_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paper_versions
    ADD CONSTRAINT paper_versions_paper_id_fkey FOREIGN KEY (paper_id) REFERENCES public.papers(id) ON DELETE CASCADE;


--
-- Name: papers papers_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.papers
    ADD CONSTRAINT papers_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: project_members project_members_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_members
    ADD CONSTRAINT project_members_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_members project_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_members
    ADD CONSTRAINT project_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: project_milestones project_milestones_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_milestones
    ADD CONSTRAINT project_milestones_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: projects projects_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- Name: references references_added_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."references"
    ADD CONSTRAINT references_added_by_fkey FOREIGN KEY (added_by) REFERENCES public.users(id);


--
-- Name: references references_paper_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."references"
    ADD CONSTRAINT references_paper_id_fkey FOREIGN KEY (paper_id) REFERENCES public.papers(id) ON DELETE SET NULL;


--
-- Name: research_interests research_interests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.research_interests
    ADD CONSTRAINT research_interests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_skills user_skills_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_skills
    ADD CONSTRAINT user_skills_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict N4ddkO3Dl2r9HS4I2VNhqXLU3EtoUO4SvKm5Pa3d1KjrhKpESrTCBd82okZTGUl

